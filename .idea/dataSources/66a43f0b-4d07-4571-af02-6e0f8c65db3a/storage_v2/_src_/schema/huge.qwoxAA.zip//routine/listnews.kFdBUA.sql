create
    definer = root@localhost procedure listnews()
begin 
  select * from tb_news;
end;

