create
    definer = root@localhost procedure login(IN uname varchar(50), IN pwd varchar(50))
begin
  select * from tb_user where username=uname and password=pwd;
end;

