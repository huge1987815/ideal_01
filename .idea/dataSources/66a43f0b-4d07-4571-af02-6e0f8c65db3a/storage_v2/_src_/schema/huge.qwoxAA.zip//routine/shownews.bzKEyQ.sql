create
    definer = root@localhost procedure shownews(IN nnid int)
begin
   select * from tb_news where nid=nnid;
end;

